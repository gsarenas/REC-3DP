// Enable Wire timeout by uncommenting the line below
#ifndef WIRE_TIMEOUT
//#define WIRE_TIMEOUT
#endif